"""Python wrapper for TruTankless water heater API"""
